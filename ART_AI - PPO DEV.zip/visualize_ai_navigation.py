import pygame
import os
import random
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback
from minimap_env import MinimapEnv
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("visualize_ai_navigation.log", mode="w"),
    ],
)
logger = logging.getLogger(__name__)

# Custom callback for detailed training statistics
class StatisticsCallback(BaseCallback):
    def __init__(self, verbose=0):
        super().__init__(verbose)

    def _on_step(self) -> bool:
        # Log detailed metrics every 10,000 steps
        if self.n_calls % 10000 == 0:
            fps = self.logger.name_to_value.get("time/fps", 0)
            total_timesteps = self.num_timesteps
            learning_rate = self.logger.name_to_value.get("train/learning_rate", "N/A")
            entropy_loss = self.logger.name_to_value.get("train/entropy_loss", "N/A")
            policy_gradient_loss = self.logger.name_to_value.get("train/policy_gradient_loss", "N/A")
            value_loss = self.logger.name_to_value.get("train/value_loss", "N/A")
            fog_cleared_ratio = self.training_env.env_method("get_total_fog_cleared")

            logger.info("-----------------------------------------")
            logger.info("| time/                   |             |")
            logger.info("|    fps                  | %d         |", fps)
            logger.info("|    total_timesteps      | %d      |", total_timesteps)
            logger.info("| train/                  |             |")
            logger.info("|    learning_rate        | %.4f      |", learning_rate)
            logger.info("|    entropy_loss         | %.4f      |", entropy_loss)
            logger.info("|    policy_gradient_loss | %.4f      |", policy_gradient_loss)
            logger.info("|    value_loss           | %.4f      |", value_loss)
            logger.info("| env/                    |             |")
            logger.info("|    fog_cleared_ratio    | %.2f      |", fog_cleared_ratio[0])
            logger.info("-----------------------------------------")

        return True

# AI with enhanced navigation and debugging
class AIPlayer:
    def __init__(self):
        self.position_history = []
        self.stuck_threshold = 10  # Steps before considering the AI stuck
        self.recovery_steps = 5    # Random recovery steps
        self.recovery_mode = False
        self.recovery_counter = 0

    def bfs_escape(self, env):
        """Perform BFS to find an escape route from a confined area."""
        from collections import deque

        directions = [(0, -5), (0, 5), (-5, 0), (5, 0)]  # Cardinal directions
        visited = set()
        queue = deque([(tuple(env.player_pos), [])])  # Queue stores (position, path)

        while queue:
            current_pos, path = queue.popleft()
            if current_pos in visited:
                continue
            visited.add(current_pos)

            # Simulate collision check without modifying env.player_pos
            if not env.is_colliding_with_walls_at(current_pos):  # Custom function
                return path  # Return the escape path

            # Add neighbors to the queue
            for i, (dx, dy) in enumerate(random.sample(directions, len(directions))):  # Randomize directions
                next_pos = (current_pos[0] + dx, current_pos[1] + dy)
                if next_pos not in visited:
                    queue.append((next_pos, path + [i]))  # Add next position and updated path

        return []  # No escape path found

    def update_position_history(self, position):
        if len(self.position_history) >= self.stuck_threshold:
            self.position_history.pop(0)
        self.position_history.append(tuple(position))

    def is_stuck(self):
        return len(self.position_history) == self.stuck_threshold and len(set(self.position_history)) == 1

    def recovery_action(self, env):
        if self.recovery_mode:
            bfs_action = self.bfs_escape(env)  # Use BFS from MinimapEnv
            if bfs_action:
                logger.info("Executing BFS-based recovery action.")
                return bfs_action[0]  # Execute the first step of the escape path
            else:
                logger.warning("No BFS escape path found. Falling back to random action.")
                return random.randint(0, 7)  # Random fallback
        return random.randint(0, 7)

    def perform_action(self, action, env):
        if self.recovery_mode:
            action = self.recovery_action(env)
            self.recovery_counter += 1
            if self.recovery_counter >= self.recovery_steps:
                self.recovery_mode = False
                self.recovery_counter = 0
        else:
            self.update_position_history(env.player_pos)
            if self.is_stuck():
                logger.info("AI detected as stuck. Entering recovery mode.")
                self.recovery_mode = True
                action = self.recovery_action(env)

        return env.step(action)


# Initialize Pygame for visualization
pygame.init()
screen = pygame.display.set_mode((600, 400))  # Match the environment's screen size
pygame.display.set_caption("AI Navigation Training Visualization")
clock = pygame.time.Clock()

# Define model save path
model_path = "minimap_ai.zip"

# Initialize or load the model
if os.path.exists(model_path):
    logger.info("Loading existing AI model...")
    model = PPO.load(model_path)
else:
    logger.info("No existing model found. Creating a new AI model...")
    env = make_vec_env(lambda: MinimapEnv(visualize=True), n_envs=1)  # Single environment for visualization
    model = PPO("MlpPolicy", env, verbose=1)

# Train the model with visualization
def train_and_visualize(
    model, env, total_timesteps=100_000, checkpoint_interval=10_000, reset_every=100_000
):
    """
    Train and visualize the AI with periodic environment resets.

    Args:
        model: The PPO model.
        env: The environment instance.
        total_timesteps (int): Total number of timesteps to train the model.
        checkpoint_interval (int): Interval for saving model checkpoints.
        reset_every (int): Number of timesteps after which the environment is reset.
    """
    observation = env.reset()[0]  # Reset environment and get initial observation
    episode_reward = 0
    steps = 0
    total_fog_cleared = 0  # Accumulate fog cleared for the current reset phase
    ai_player = AIPlayer()

    for timestep in range(1, total_timesteps + 1):
        # Check for quit events to prevent crashes
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                logger.info("Exiting visualization.")
                env.close()
                pygame.quit()
                return

        # AI takes action
        action, _ = model.predict(observation, deterministic=False)
        next_state, reward, done, truncated, info = ai_player.perform_action(action, env)

        # Accumulate reward and fog cleared
        episode_reward += reward
        steps += 1
        total_fog_cleared += info.get("fog_revealed", 0)

        # Check if the episode is done or truncated
        if done or truncated:
            logger.info("Episode ended. Total reward: %.2f, Steps: %d", episode_reward, steps)
            observation = env.reset()[0]
            episode_reward = 0
            steps = 0

        # Periodic reset of the environment
        if timestep % reset_every == 0:
            logger.info("===================================================")
            logger.info("Resetting the environment at timestep %d...", timestep)
            logger.info("Total fog blocks cleared during this phase: %d", total_fog_cleared)
            logger.info("===================================================")
            observation = env.reset()[0]
            episode_reward = 0
            steps = 0
            total_fog_cleared = 0  # Reset fog cleared count for the next phase

        # Render the environment at intervals (e.g., every 5 steps)
        if timestep % 5 == 0:
            env.render()

        # Save model checkpoint
        if timestep % checkpoint_interval == 0:
            logger.info("Saving model checkpoint at timestep %d...", timestep)
            model.save(model_path)

        # Log detailed stats every 10,000 steps
        if timestep % 10_000 == 0:
            logger.info("-----------------------------------------")
            logger.info("| Timestep: %d                           |", timestep)
            logger.info("| Episode Reward: %.2f                  |", episode_reward)
            logger.info("| Steps in Episode: %d                  |", steps)
            logger.info("-----------------------------------------")

        # Control frame rate
        clock.tick(10)  # Lower FPS to reduce resource usage

    # Final save
    logger.info("Training complete. Saving final model...")
    model.save(model_path)


# Run the training process
if __name__ == "__main__":
    env = MinimapEnv(visualize=True)  # Visualization explicitly enabled
    stats_callback = StatisticsCallback()
    train_and_visualize(model, env, total_timesteps=100_000)
    env.close()
    pygame.quit()
