import os
import logging
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.logger import configure
from stable_baselines3.common.callbacks import CheckpointCallback, BaseCallback
from minimap_env import MinimapEnv
from stable_baselines3.common.callbacks import CallbackList


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("train_ai.log", mode="a"),  # Append to existing log
    ],
)
logger = logging.getLogger(__name__)

# Model and directories
MODEL_PATH = "minimap_ai.zip"
LOG_DIR = "./logs"
CHECKPOINT_DIR = "./checkpoints"
os.makedirs(LOG_DIR, exist_ok=True)
os.makedirs(CHECKPOINT_DIR, exist_ok=True)

# Custom callback for detailed training statistics
class StatisticsCallback(BaseCallback):
    def __init__(self, verbose=0):
        super().__init__(verbose)

    def _on_step(self) -> bool:
        # Log detailed metrics every 10,000 steps
        if self.n_calls % 10000 == 0:
            fps = self.logger.name_to_value.get("time/fps", 0)
            total_timesteps = self.num_timesteps
            learning_rate = self.logger.name_to_value.get("train/learning_rate", "N/A")
            entropy_loss = self.logger.name_to_value.get("train/entropy_loss", "N/A")
            policy_gradient_loss = self.logger.name_to_value.get("train/policy_gradient_loss", "N/A")
            value_loss = self.logger.name_to_value.get("train/value_loss", "N/A")

            logger.info("-----------------------------------------")
            logger.info("| time/                   |             |")
            logger.info("|    fps                  | %d         |", fps)
            logger.info("|    total_timesteps      | %d      |", total_timesteps)
            logger.info("| train/                  |             |")
            logger.info("|    learning_rate        | %.4f      |", learning_rate)
            logger.info("|    entropy_loss         | %.4f      |", entropy_loss)
            logger.info("|    policy_gradient_loss | %.4f      |", policy_gradient_loss)
            logger.info("|    value_loss           | %.4f      |", value_loss)
            logger.info("-----------------------------------------")

        return True

# Ensure observation space matches
def validate_observation_space(env):
    obs, _ = env.reset()
    if obs.shape[0] != env.observation_space.shape[0]:
        raise ValueError("Observation space mismatch! Check the environment setup.")

# Main training function
def train_model(total_timesteps=1000_000, reset_every=100_000):
    """
    Train the PPO model with periodic environment resets.

    Args:
        total_timesteps (int): Total timesteps to train the model.
        reset_every (int): Number of timesteps after which the environment is reset.
    """
    # Create a headless training environment
    logger.info("Creating headless training environment...")
    env = make_vec_env(lambda: MinimapEnv(visualize=False), n_envs=8)

    # Validate observation space
    validate_observation_space(env.envs[0].unwrapped)

    # Load existing model or create a new one
    if os.path.exists(MODEL_PATH):
        logger.info("Loading existing model from %s", MODEL_PATH)
        model = PPO.load(MODEL_PATH, env=env)
    else:
        logger.info("No existing model found. Initializing a new model...")
        model = PPO("MlpPolicy", env, verbose=1, n_steps=2048)

    # Configure logging for Stable-Baselines3
    model.set_logger(configure(LOG_DIR))

    # Define callbacks
    checkpoint_callback = CheckpointCallback(
        save_freq=100_000,  # Save model every 100,000 steps
        save_path=CHECKPOINT_DIR,
        name_prefix="ppo_checkpoint",
    )
    stats_callback = StatisticsCallback(verbose=1)
    callback = CallbackList([checkpoint_callback, stats_callback])

    # Training loop with periodic resets
    logger.info("Starting model training for %d timesteps...", total_timesteps)
    timesteps_done = 0
    total_fog_cleared = 0  # Accumulate fog cleared for the current reset phase

    while timesteps_done < total_timesteps:
        # Train for the next segment of timesteps
        timesteps_to_train = min(reset_every, total_timesteps - timesteps_done)
        logger.info(
            "Training for %d timesteps (segment %d)...",
            timesteps_to_train,
            timesteps_done // reset_every + 1,
        )
        model.learn(total_timesteps=timesteps_to_train, callback=callback)

        # Fetch fog cleared from all environments
        fog_cleared_envs = env.env_method("get_total_fog_cleared")
        total_fog_cleared = sum(fog_cleared_envs)

        # Reset the environment after the segment
        logger.info("===================================================")
        logger.info(
            "Resetting the environment after %d timesteps...", timesteps_done + timesteps_to_train
        )
        logger.info("Total fog blocks cleared during this phase: %d", total_fog_cleared)
        logger.info("===================================================")
        env.env_method("reset")
        timesteps_done += timesteps_to_train
        total_fog_cleared = 0  # Reset fog cleared count for the next phase

    # Save the final model
    logger.info("Training complete. Saving final model to %s", MODEL_PATH)
    model.save(MODEL_PATH)

    # Close the environment
    env.close()


if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Train the AI model.")
    parser.add_argument(
        "--timesteps", type=int, default=1000_000, help="Number of timesteps to train the model"
    )
    args = parser.parse_args()

    train_model(total_timesteps=args.timesteps)
