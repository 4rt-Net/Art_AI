################################################
################################################
#####  minimap_env.py


import pygame
import numpy as np
import random
import os
from gymnasium import Env, spaces
from minimap_simulator import generate_maze_chunk, update_fog_of_war, CHUNK_SIZE, MAZE_CELL_SIZE, FOG_BLOCK_SIZE
from colorama import Fore, Style
from minimap_simulator import BACKGROUND_COLOR, WALL_COLOR, PLAYER_COLOR
import logging
from minimap_simulator import PLAYER_REVEAL_RADIUS


# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("minimap_env.log", mode="w"),
    ],
)
logger = logging.getLogger(__name__)

# Proximity grid constants
PROXIMITY_RADIUS = 3  # Radius of the proximity grid (in blocks)
PROXIMITY_GRID_SIZE = (PROXIMITY_RADIUS * 2 + 1) ** 2  # Size of the flattened proximity grid


class MinimapEnv(Env):
    def __init__(self, visualize=False):
        super().__init__()
        self.visualize = visualize
        self.screen_width = 600
        self.screen_height = 400
        self.player_reveal_radius = 100
        self.chunk_size = CHUNK_SIZE
        self.maze_cell_size = MAZE_CELL_SIZE
        self.position_history = []  # To track the last N positions
        self.recovery_mode = False
        self.recovery_counter = 0
        self.recovery_steps = 10
        self.visited_positions = set()  # To track visited positions
        self.visited_map = {}


        # Observation space: fog state + player position (x, y) + proximity grid
        self.observation_space = spaces.Box(
            low=0,
            high=1,
            shape=(
                (CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE) ** 2 + 2 + PROXIMITY_GRID_SIZE,
            ),
            dtype=np.float32,
        )


        # Action space: 8 directions (Up, Down, Left, Right, Diagonals)
        self.action_space = spaces.Discrete(8)

        # Internal state
        self.player_pos = np.array([self.screen_width // 2, self.screen_height // 2])
        self.maze_chunks = {}
        self.fog_chunks = {}
        self.done = False

        # Initialize visible chunks and fog
        self.update_visible_chunks()

        # Additional state for rewards
        self.fog_cleared_total = 0
        self.steps_without_progress = 0

        # Initialize Pygame for visualization
        if self.visualize:
            pygame.init()
            self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
            pygame.display.set_caption("Minimap Environment")
        else:
            os.environ["SDL_VIDEODRIVER"] = "dummy"
            pygame.display.init()
            self.screen = pygame.Surface((self.screen_width, self.screen_height))

    def a_star_pathfinding(self, start, goal):
        """
        Perform A* pathfinding to find the optimal path from start to goal.
        """
        from heapq import heappush, heappop

        def heuristic(a, b):
            return abs(a[0] - b[0]) + abs(a[1] - b[1])

        open_set = []
        heappush(open_set, (0, start))
        came_from = {}
        g_score = {start: 0}
        f_score = {start: heuristic(start, goal)}

        while open_set:
            _, current = heappop(open_set)

            if current == goal:
                path = []
                while current in came_from:
                    path.append(current)
                    current = came_from[current]
                return path[::-1]

            for neighbor in self.get_neighbors(current):
                tentative_g_score = g_score[current] + 1

                if neighbor not in g_score or tentative_g_score < g_score[neighbor]:
                    came_from[neighbor] = current
                    g_score[neighbor] = tentative_g_score
                    f_score[neighbor] = g_score[neighbor] + heuristic(neighbor, goal)
                    heappush(open_set, (f_score[neighbor], neighbor))

        return []  # Return an empty path if no path found

    def get_total_fog_cleared(self):
        """
        Return the total fog blocks cleared in the environment.
        """
        return self.fog_cleared_total


    def get_neighbors(self, position):
        """
        Get valid neighbors for a given position.
        """
        directions = [(-5, 0), (5, 0), (0, -5), (0, 5)]
        neighbors = []
        for dx, dy in directions:
            neighbor = (position[0] + dx, position[1] + dy)
            if not self.is_colliding_with_walls_at(neighbor):
                neighbors.append(neighbor)
        return neighbors


    def get_proximity_grid(self, player_pos, radius=PROXIMITY_RADIUS):
        """
        Generate a grid indicating the presence of walls, open areas, and fog around the player,
        aligned with the reveal radius.

        Args:
            player_pos (array): The player's current position [x, y].
            radius (int): The radius (in blocks) to scan for walls.

        Returns:
            np.array: A 2D grid with:
                - 1s for walls
                - 0s for open spaces
                - -1 for fog (unknown areas)
        """
        proximity_grid = np.zeros((radius * 2 + 1, radius * 2 + 1), dtype=int)
        grid_center = radius

        for dx in range(-radius, radius + 1):
            for dy in range(-radius, radius + 1):
                # Calculate the grid cell's actual coordinates in the environment
                grid_x = player_pos[0] + dx * FOG_BLOCK_SIZE
                grid_y = player_pos[1] + dy * FOG_BLOCK_SIZE

                # Check if the cell falls outside the circular reveal radius
                if (dx * FOG_BLOCK_SIZE) ** 2 + (dy * FOG_BLOCK_SIZE) ** 2 > PLAYER_REVEAL_RADIUS ** 2:
                    continue  # Skip cells outside the circle

                # Check for wall collisions
                if any(
                    wall.collidepoint(grid_x, grid_y)
                    for chunk, walls in self.maze_chunks.items()
                    for wall in walls
                ):
                    proximity_grid[grid_center + dx, grid_center + dy] = 1  # Wall detected
                elif any(
                    fog[int((grid_y // FOG_BLOCK_SIZE) % fog.shape[0]), int((grid_x // FOG_BLOCK_SIZE) % fog.shape[1])] == 1
                    for chunk, fog in self.fog_chunks.items()
                ):
                    proximity_grid[grid_center + dx, grid_center + dy] = -1  # Fog detected

            # Unvisited and valid open spaces remain as 0
        return proximity_grid



    def bfs_escape(self):
        from collections import deque

        directions = [(0, -5), (0, 5), (-5, 0), (5, 0)]  # Cardinal directions
        visited = set()
        queue = deque([(tuple(self.player_pos), [])])  # Queue stores (position, path)

        while queue:
            current_pos, path = queue.popleft()
            if current_pos in visited:
                continue
            visited.add(current_pos)

            # Check if position is valid and not colliding
            if not self.is_colliding_with_walls_at(current_pos) and current_pos not in self.visited_map:
                return path[0] if path else None  # Return the first action in the path

            # Add neighbors to the queue
            for i, (dx, dy) in enumerate(directions):
                next_pos = (current_pos[0] + dx, current_pos[1] + dy)
                if next_pos not in visited:
                    queue.append((next_pos, path + [i]))

        # Fallback to random action
        return random.randint(0, 3)

    def is_chunk_cleared(self, chunk_x, chunk_y):
        """
        Check if a given chunk is fully cleared of fog.
        """
        fog = self.fog_chunks.get((chunk_x, chunk_y))
        if fog is None:
            return False
        return np.all(fog == 0)


    def is_colliding_with_walls_at(self, position):
        """
        Check for collisions at a given position without modifying player_pos.
        """
        for chunk, walls in self.maze_chunks.items():
            for wall in walls:
                wall_rect = pygame.Rect(wall)
                player_rect = pygame.Rect(
                    position[0] - 5, position[1] - 5, 10, 10  # Match player size
                )
                if wall_rect.colliderect(player_rect):
                    return True
        return False

    def is_colliding_with_walls(self):
        """
        Check if the player is colliding with any walls at their current position.
        """
        return self.is_colliding_with_walls_at(self.player_pos)


    def find_valid_spawn_position(self):
        """
        Find a valid position for the player that is not inside a wall or enclosed loop.
        """
        while True:
            x = random.randint(0, self.screen_width)
            y = random.randint(0, self.screen_height)

            player_rect = pygame.Rect(x - 5, y - 5, 10, 10)
            collision = False

            for chunk, walls in self.maze_chunks.items():
                for wall in walls:
                    wall_rect = pygame.Rect(wall)
                    if wall_rect.colliderect(player_rect):
                        collision = True
                        break
                if collision:
                    break

            if not collision:
                return np.array([x, y])

    def step(self, action, retry_limit=10):
        """
        Take an action in the environment and update the state.
        """
        # Save original position
        original_pos = self.player_pos.copy()

        ##########################
        # Movement and Boundaries
        ##########################
        movement_deltas = [
            (0, -5),  # Move up
            (0, 5),   # Move down
            (-5, 0),  # Move left
            (5, 0),   # Move right
            (-5, -5), # Move up + left
            (5, -5),  # Move up + right
            (-5, 5),  # Move down + left
            (5, 5)    # Move down + right
        ]

        dx, dy = movement_deltas[action]
        self.player_pos[0] = max(0, min(self.screen_width - 1, self.player_pos[0] + dx))
        self.player_pos[1] = max(0, min(self.screen_height - 1, self.player_pos[1] + dy))

        ##########################
        # Collision Handling
        ##########################
        if self.is_colliding_with_walls():
            logger.warning(f"Collision detected at position: {self.player_pos}")
            self.player_pos = original_pos  # Revert to previous position

            # Try escaping using BFS
            if retry_limit > 0:
                bfs_action = self.bfs_escape()
                if bfs_action is not None:
                    logger.info("Using BFS to escape collision.")
                    return self.step(bfs_action, retry_limit - 1)  # Retry step with BFS action
            else:
                logger.warning("Retry limit reached. Taking random action to resolve collision.")
                action = random.randint(0, 7)  # Random fallback
                return self.step(action, retry_limit - 1)

            # Penalize collisions
            reward = -3
        else:
            reward = 0.2  # Small reward for valid movement

        ##########################
        # Fog Clearing and Rewards
        ##########################
        fog_revealed = update_fog_of_war(self.player_pos, self.fog_chunks)
        self.fog_cleared_total += fog_revealed

        if fog_revealed > 0:
            reward += fog_revealed * 3  # Strong reward for clearing fog
            self.steps_without_progress = 0

            # Bonus for clearing a chunk
            player_chunk_x = self.player_pos[0] // (self.chunk_size * self.maze_cell_size)
            player_chunk_y = self.player_pos[1] // (self.chunk_size * self.maze_cell_size)
            if self.is_chunk_cleared(player_chunk_x, player_chunk_y):
                reward += 10
        else:
            self.steps_without_progress += 1
            reward -= 0.2

            # Penalize excessive steps without progress
            if self.steps_without_progress > 10:
                logger.info("Excessive steps without progress. Penalizing.")
                reward -= 3

        ##########################
        # Exploration Rewards
        ##########################
        if tuple(self.player_pos) in self.visited_map:
            reward -= 0.5  # Penalty for revisiting
        else:
            self.visited_map[tuple(self.player_pos)] = True
            reward += 1.0  # Reward for exploring new areas

        ##########################
        # Termination Check
        ##########################
        terminated = self.is_done()
        truncated = False

        ##########################
        # Return Updated State
        ##########################
        return self.get_observation(), reward, terminated, truncated, {
            "fog_revealed": fog_revealed,
            "steps_without_progress": self.steps_without_progress,
        }



    def reset(self, seed=None, options=None):
        """
        Reset the environment, including fog and map.

        Args:
            seed (int, optional): Seed for reproducibility.
            options (dict, optional): Additional options.

        Returns:
            observation (np.array): Initial observation after reset.
        """
        super().reset(seed=seed)

        # Clear and reinitialize chunks
        self.fog_chunks.clear()
        self.maze_chunks.clear()
        self.fog_cleared_total = 0
        self.visited_positions.clear()  # Clear visited positions

        # Generate chunks and place the player in the center
        self.update_visible_chunks()
        self.player_pos = np.array([self.screen_width // 2, self.screen_height // 2])

        logger.info("Environment reset. Player starting at position: %s", self.player_pos)
        return self.get_observation(), {}


    def is_done(self):
        total_fog_blocks = sum(fog.size for fog in self.fog_chunks.values())
        if total_fog_blocks == 0:
            return False
        revealed_blocks = sum((fog == 0).sum() for fog in self.fog_chunks.values())
        return revealed_blocks / total_fog_blocks > 0.8

    def get_observation(self):
        """
        Extend observation space to include fog state, player position, and proximity grid.
        """
        fog_state = np.hstack(
            [fog.flatten() for fog in self.fog_chunks.values()]
        )
        expected_length = (CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE) ** 2

        if len(fog_state) < expected_length:
            fog_state = np.pad(fog_state, (0, expected_length - len(fog_state)), constant_values=1)
        elif len(fog_state) > expected_length:
            fog_state = fog_state[:expected_length]

        player_normalized = self.player_pos / [self.screen_width, self.screen_height]

        # Generate proximity grid (now synchronized with reveal radius)
        proximity_grid = self.get_proximity_grid(self.player_pos, radius=PROXIMITY_RADIUS)
        proximity_flattened = proximity_grid.flatten() * 0.1

        # Combine all components into one observation vector
        return np.concatenate([fog_state, player_normalized, proximity_flattened])

        
    def update_visible_chunks(self):
        player_chunk_x = self.player_pos[0] // (self.chunk_size * self.maze_cell_size)
        player_chunk_y = self.player_pos[1] // (self.chunk_size * self.maze_cell_size)

        for dx in range(-1, 2):
            for dy in range(-1, 2):
                chunk = (player_chunk_x + dx, player_chunk_y + dy)
                if chunk not in self.maze_chunks:
                    self.maze_chunks[chunk] = generate_maze_chunk(*chunk)
                if chunk not in self.fog_chunks:
                    self.fog_chunks[chunk] = np.ones(
                        (
                            self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE,
                            self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE,
                        )
                    )

    def render(self):
        if not self.visualize:
            return

        # Center the view on the player's position
        offset_x = self.player_pos[0] - self.screen_width // 2
        offset_y = self.player_pos[1] - self.screen_height // 2

        self.screen.fill(BACKGROUND_COLOR)

        for chunk, walls in self.maze_chunks.items():
            for wall in walls:
                pygame.draw.rect(self.screen, WALL_COLOR, wall.move(-offset_x, -offset_y))

        for (chunk_x, chunk_y), fog in self.fog_chunks.items():
            chunk_offset_x = chunk_x * self.chunk_size * self.maze_cell_size
            chunk_offset_y = chunk_y * self.chunk_size * self.maze_cell_size
            for x, y in zip(*np.where(fog == 1)):
                pygame.draw.rect(
                    self.screen,
                    (10, 10, 10),
                    pygame.Rect(
                        chunk_offset_x + x * FOG_BLOCK_SIZE - offset_x,
                        chunk_offset_y + y * FOG_BLOCK_SIZE - offset_y,
                        FOG_BLOCK_SIZE,
                        FOG_BLOCK_SIZE,
                    ),
                )

        pygame.draw.circle(self.screen, PLAYER_COLOR, (self.screen_width // 2, self.screen_height // 2), 10)
        pygame.display.flip()

    def close(self):
        if self.visualize:
            pygame.quit()
