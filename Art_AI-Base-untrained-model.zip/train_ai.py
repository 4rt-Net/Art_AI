from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback
from minimap_env import MinimapEnv
from colorama import Fore, Style
import os


# Custom callback to render and log during training
class DebugCallback(BaseCallback):
    def __init__(self, verbose=0):
        super().__init__(verbose)

    def _on_step(self) -> bool:
        # Unwrap the Monitor object to access the original environment
        env = self.training_env.envs[0].unwrapped

        # Access the player's position from the unwrapped environment
        player_pos = env.player_pos

        # Log debugging information
        print(f"{Fore.CYAN}[DEBUG]{Style.RESET_ALL} Action: {self.locals['actions']}, Player position: {player_pos}, "
              f"Reward: {self.locals['rewards']}, Done: {self.locals['dones']}")
        return True


# Custom callback for checkpointing models
class CheckpointCallback(BaseCallback):
    def __init__(self, save_freq: int, save_path: str, verbose=0):
        super().__init__(verbose)
        self.save_freq = save_freq
        self.save_path = save_path
        os.makedirs(save_path, exist_ok=True)  # Ensure save directory exists

    def _on_step(self) -> bool:
        if self.n_calls % self.save_freq == 0:
            checkpoint_path = os.path.join(self.save_path, f"model_checkpoint_{self.n_calls}.zip")
            self.model.save(checkpoint_path)
            if self.verbose > 0:
                print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Saved model checkpoint at step {self.n_calls} to {checkpoint_path}")
        return True


# Create a vectorized environment
env = make_vec_env(lambda: MinimapEnv(), n_envs=3)

# Check if a previous model exists and load it
if os.path.exists("minimap_ai.zip"):
    print(f"{Fore.YELLOW}[INFO]{Style.RESET_ALL} Found previous model. Loading it for continued training.")
    model = PPO.load("minimap_ai", env=env)
else:
    print(f"{Fore.YELLOW}[INFO]{Style.RESET_ALL} No previous model found. Starting fresh.")
    model = PPO("MlpPolicy", env, verbose=1)

# Define the checkpoint callback
checkpoint_callback = CheckpointCallback(save_freq=20_000, save_path="./checkpoints", verbose=1)

# Train the model with DebugCallback and CheckpointCallback
print("Training starts...")
model.learn(total_timesteps=200_000, callback=[DebugCallback(verbose=1), checkpoint_callback])

# Save the final trained model
model.save("minimap_ai")
print(f"{Fore.GREEN}[INFO]{Style.RESET_ALL} Training completed. Final model saved as 'minimap_ai'.")

# Close the environment
env.close()
