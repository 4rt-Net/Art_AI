import numpy as np
import random
from gymnasium import Env, spaces
from minimap_simulator import generate_maze_chunk, update_fog_of_war, CHUNK_SIZE, MAZE_CELL_SIZE, FOG_BLOCK_SIZE
from colorama import Fore, Style

class MinimapEnv(Env):
    def __init__(self):
        super().__init__()
        self.screen_width = 600
        self.screen_height = 400
        self.player_reveal_radius = 100
        self.chunk_size = CHUNK_SIZE
        self.maze_cell_size = MAZE_CELL_SIZE

        # Observation space: flattened fog state + player position (x, y)
        self.observation_space = spaces.Box(
            low=0,
            high=1,
            shape=((CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE) ** 2 + 2,),
            dtype=np.float32,
        )

        # Action space: Up, Down, Left, Right
        self.action_space = spaces.Discrete(4)

        # Internal state
        self.player_pos = np.array([self.screen_width // 2, self.screen_height // 2])
        self.maze_chunks = {}
        self.fog_chunks = {}
        self.done = False

        # Initialize visible chunks and fog
        self.update_visible_chunks()

    def update_visible_chunks(self):
        """
        Ensure all visible chunks around the player are generated and fog is initialized.
        """
        player_chunk_x = self.player_pos[0] // (self.chunk_size * self.maze_cell_size)
        player_chunk_y = self.player_pos[1] // (self.chunk_size * self.maze_cell_size)
        print(f"{Fore.BLUE}[Minimap AI]: Scouting nearby areas... Current chunk: ({player_chunk_x}, {player_chunk_y}){Style.RESET_ALL}")

        for dx in range(-1, 2):
            for dy in range(-1, 2):
                chunk = (player_chunk_x + dx, player_chunk_y + dy)
                if chunk not in self.maze_chunks:
                    self.maze_chunks[chunk] = generate_maze_chunk(*chunk)
                if chunk not in self.fog_chunks:
                    self.fog_chunks[chunk] = np.ones(
                        (
                            self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE,
                            self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE,
                        )
                    )

    def reset(self, seed=None, options=None):
        """
        Reset the environment to its initial state.
        """
        self.player_pos = np.array([self.screen_width // 2, self.screen_height // 2])
        self.fog_chunks.clear()
        self.maze_chunks.clear()
        self.update_visible_chunks()
        #print("[DEBUG] Environment reset. Player position:", self.player_pos)
        print(f"{Fore.YELLOW}[Minimap AI]: Starting fresh! Player is now ready at position: {self.player_pos}{Style.RESET_ALL}")
        return self.get_observation(), {}

    def step(self, action):
        # Update player position
        if action == 0:  # Move up
            self.player_pos[1] = max(0, self.player_pos[1] - 5)
        elif action == 1:  # Move down
            self.player_pos[1] = min(self.screen_height, self.player_pos[1] + 5)
        elif action == 2:  # Move left
            self.player_pos[0] = max(0, self.player_pos[0] - 5)
        elif action == 3:  # Move right
            self.player_pos[0] = min(self.screen_width, self.player_pos[0] + 5)

        # Update fog and calculate rewards
        fog_revealed_edges = update_fog_of_war(self.player_pos, self.fog_chunks)
        fog_revealed = len(fog_revealed_edges)  # Total number of fog-revealed blocks

        reward = fog_revealed if fog_revealed > 0 else -0.1

        # Update reward range and normalize
        if not hasattr(self, "min_reward"):
            self.min_reward = reward
            self.max_reward = reward

        self.min_reward = min(self.min_reward, reward)
        self.max_reward = max(self.max_reward, reward)

        if self.max_reward > self.min_reward:
            reward = (reward - self.min_reward) / (self.max_reward - self.min_reward) * 2 - 1

        # Check if the episode is done
        terminated = self.is_done()
        truncated = False  # No truncation logic implemented; set to False

        # Debug message with styled output
        print(f"{Fore.GREEN}[Minimap AI]: Action taken: {action}. "
              f"Player moved to: {self.player_pos}. Reward: {reward:.2f}, "
              f"Fog revealed: {fog_revealed} blocks{Style.RESET_ALL}")

        return self.get_observation(), reward, terminated, truncated, {"fog_revealed": fog_revealed}


    def is_done(self):
        """
        Determine if the episode is done (e.g., when a percentage of the map is revealed).
        """
        total_fog_blocks = sum(fog.size for fog in self.fog_chunks.values())
        if total_fog_blocks == 0:
            return False  # Avoid division by zero
        revealed_blocks = sum((fog == 0).sum() for fog in self.fog_chunks.values())
        print(f"{Fore.MAGENTA}[Minimap AI]: Progress check... {revealed_blocks}/{total_fog_blocks} blocks revealed!{Style.RESET_ALL}")
        return revealed_blocks / total_fog_blocks > 0.8  # Ends when 80% of fog is cleared

    def get_observation(self):
        """
        Get the current observation: flattened fog state + player position.
        """
        # Flatten fog chunks into a single array
        fog_state = np.hstack(
            [
                fog.flatten()
                for fog in self.fog_chunks.values()
            ]
        )
        expected_length = (CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE) ** 2

        # Pad or trim the fog state to match the expected length
        if len(fog_state) < expected_length:
            fog_state = np.pad(fog_state, (0, expected_length - len(fog_state)), constant_values=1)
        elif len(fog_state) > expected_length:
            fog_state = fog_state[:expected_length]

        # Normalize player position and concatenate
        player_normalized = self.player_pos / [self.screen_width, self.screen_height]
        return np.concatenate([fog_state, player_normalized])
