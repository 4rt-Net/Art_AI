# train_ai.py

import os
import logging
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from stable_baselines3.common.callbacks import BaseCallback
from stable_baselines3.common.logger import configure
from minimap_env import MinimapEnv

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("train_ai.log", mode="w"),
    ],
)
logger = logging.getLogger(__name__)

# Custom callback for logging training statistics
class StatisticsCallback(BaseCallback):
    def __init__(self, verbose=0):
        super().__init__(verbose)

    def _on_step(self) -> bool:
        # Log every 10,000 steps
        if self.n_calls % 10000 == 0:
            fps = self.logger.name_to_value.get("time/fps", 0)
            iterations = self.logger.name_to_value.get("time/iterations", 0)
            total_timesteps = self.logger.name_to_value.get("time/total_timesteps", 0)
            approx_kl = self.logger.name_to_value.get("train/approx_kl", "N/A")
            entropy_loss = self.logger.name_to_value.get("train/entropy_loss", "N/A")
            explained_variance = self.logger.name_to_value.get("train/explained_variance", "N/A")

            logger.info("-----------------------------------------")
            logger.info("| time/                   |             |")
            logger.info("|    fps                  | %d         |", fps)
            logger.info("|    iterations           | %d          |", iterations)
            logger.info("|    total_timesteps      | %d      |", total_timesteps)
            logger.info("| train/                  |             |")
            logger.info("|    approx_kl            | %s |", approx_kl)
            logger.info("|    entropy_loss         | %s       |", entropy_loss)
            logger.info("|    explained_variance   | %s     |", explained_variance)
            logger.info("-----------------------------------------")

        return True

# Ensure observation space matches
def validate_observation_space(env):
    obs, _ = env.reset()
    if obs.shape[0] != env.observation_space.shape[0]:
        raise ValueError("Observation space mismatch! Check the environment setup.")

# Main training function
def main():
    # Create a headless training environment
    logger.info("Creating headless training environment...")
    env = make_vec_env(lambda: MinimapEnv(visualize=False), n_envs=4)

    # Validate the observation space
    validate_observation_space(env.envs[0].unwrapped)

    # Load or initialize the model
    model_path = "minimap_ai.zip"
    if os.path.exists(model_path):
        logger.info("Loading existing model from %s", model_path)
        model = PPO.load(model_path, env=env)
    else:
        logger.info("No existing model found. Initializing a new model...")
        model = PPO("MlpPolicy", env, verbose=1)

    # Configure Stable-Baselines3 logging to use a specific directory
    log_dir = "./logs"
    os.makedirs(log_dir, exist_ok=True)
    model.set_logger(configure(log_dir))

    # Define callbacks
    checkpoint_callback = StatisticsCallback(verbose=1)

    # Train the model
    logger.info("Starting model training...")
    model.learn(total_timesteps=20_000, callback=checkpoint_callback)

    # Save the final model
    logger.info("Saving final model to %s", model_path)
    model.save(model_path)

    # Close the environment
    env.close()

if __name__ == "__main__":
    main()
