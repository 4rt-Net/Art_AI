# minimap_env.py

import pygame
import numpy as np
import random
import os
from gymnasium import Env, spaces
from minimap_simulator import generate_maze_chunk, update_fog_of_war, CHUNK_SIZE, MAZE_CELL_SIZE, FOG_BLOCK_SIZE
from colorama import Fore, Style
from minimap_simulator import BACKGROUND_COLOR, WALL_COLOR, PLAYER_COLOR, FOG_BLOCK_SIZE
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("minimap_env.log", mode="w"),
    ],
)
logger = logging.getLogger(__name__)


class MinimapEnv(Env):
    def __init__(self, visualize=False):
        super().__init__()
        self.visualize = visualize  # Enable or disable visualization
        self.screen_width = 600
        self.screen_height = 400
        self.player_reveal_radius = 100
        self.chunk_size = CHUNK_SIZE
        self.maze_cell_size = MAZE_CELL_SIZE

        # Observation space: flattened fog state + player position (x, y)
        self.observation_space = spaces.Box(
            low=0,
            high=1,
            shape=((CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE) ** 2 + 2,),
            dtype=np.float32,
        )

        # Action space: Up, Down, Left, Right
        self.action_space = spaces.Discrete(4)

        # Internal state
        self.player_pos = np.array([self.screen_width // 2, self.screen_height // 2])
        self.maze_chunks = {}
        self.fog_chunks = {}
        self.done = False

        # Initialize visible chunks and fog
        self.update_visible_chunks()

        # Additional state for rewards
        self.fog_cleared_total = 0  # Track total fog cleared
        self.steps_without_progress = 0  # Count steps with no progress

        # Recovery mode
        self.recovery_mode = False
        self.recovery_counter = 0
        self.recovery_steps = 10

        # Initialize Pygame for visualization
        if self.visualize:
            pygame.init()
            self.screen = pygame.display.set_mode((self.screen_width, self.screen_height))
            pygame.display.set_caption("Minimap Environment")
        else:
            os.environ["SDL_VIDEODRIVER"] = "dummy"
            pygame.display.init()
            self.screen = pygame.Surface((self.screen_width, self.screen_height))

    def step(self, action):
        # Update player position based on action
        if action == 0:  # Up
            self.player_pos[1] = max(self.player_pos[1] - 1, 0)
        elif action == 1:  # Down
            self.player_pos[1] = min(self.player_pos[1] + 1, self.screen_height - 1)
        elif action == 2:  # Left
            self.player_pos[0] = max(self.player_pos[0] - 1, 0)
        elif action == 3:  # Right
            self.player_pos[0] = min(self.player_pos[0] + 1, self.screen_width - 1)

        # Update visible chunks and calculate reward
        self.update_visible_chunks()
        reward = self.calculate_reward()

        # Check if the episode is done
        self.done = self.check_done()

        # Return observation, reward, done flag, and info
        return self.get_observation(), reward, self.done, {}

    def reset(self):
        self.player_pos = np.array([self.screen_width // 2, self.screen_height // 2])
        self.update_visible_chunks()
        self.done = False
        self.fog_cleared_total = 0
        self.steps_without_progress = 0
        return self.get_observation()

    def get_observation(self):
        # Flatten fog state and add player position
        fog_flattened = np.zeros((self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE) ** 2)
        return np.concatenate([fog_flattened, self.player_pos])

    def update_visible_chunks(self):
        # Update visible chunks based on player position
        pass

    def calculate_reward(self):
        # Calculate reward based on fog cleared and other metrics
        return 1.0  # Placeholder

    def check_done(self):
        # Define termination condition
        return self.fog_cleared_total >= 100  # Example condition


    def update_visible_chunks(self):
        """
        Ensure all visible chunks around the player are generated and fog is initialized.
        """
        player_chunk_x = self.player_pos[0] // (self.chunk_size * self.maze_cell_size)
        player_chunk_y = self.player_pos[1] // (self.chunk_size * self.maze_cell_size)
        logger.debug(f"Scouting nearby areas... Current chunk: ({player_chunk_x}, {player_chunk_y})")

        for dx in range(-1, 2):
            for dy in range(-1, 2):
                chunk = (player_chunk_x + dx, player_chunk_y + dy)
                if chunk not in self.maze_chunks:
                    self.maze_chunks[chunk] = generate_maze_chunk(*chunk)
                if chunk not in self.fog_chunks:
                    self.fog_chunks[chunk] = np.ones(
                        (
                            self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE,
                            self.chunk_size * self.maze_cell_size // FOG_BLOCK_SIZE,
                        )
                    )

    def render(self):
        """
        Render the environment using Pygame.
        Only render if visualization is enabled.
        """
        if not self.visualize:
            return  # Skip rendering in headless mode

        # Clear the screen
        self.screen.fill(BACKGROUND_COLOR)

        # Draw maze walls
        for chunk, walls in self.maze_chunks.items():
            for wall in walls:
                pygame.draw.rect(self.screen, WALL_COLOR, wall)

        # Draw fog of war
        for (chunk_x, chunk_y), fog in self.fog_chunks.items():
            chunk_offset_x = chunk_x * self.chunk_size * self.maze_cell_size
            chunk_offset_y = chunk_y * self.chunk_size * self.maze_cell_size
            for x, y in zip(*np.where(fog == 1)):  # Fogged blocks
                pygame.draw.rect(
                    self.screen,
                    (10, 10, 10),  # Fog color
                    pygame.Rect(
                        chunk_offset_x + x * FOG_BLOCK_SIZE,
                        chunk_offset_y + y * FOG_BLOCK_SIZE,
                        FOG_BLOCK_SIZE,
                        FOG_BLOCK_SIZE,
                    ),
                )

        # Draw the player
        player_x, player_y = self.player_pos
        pygame.draw.circle(self.screen, PLAYER_COLOR, (int(player_x), int(player_y)), 10)

        # Update the display
        pygame.display.flip()

    def find_valid_spawn_position(self):
        """
        Find a valid position for the player that is not inside a wall.
        """
        while True:
            # Randomly generate a position within the screen bounds
            x = random.randint(0, self.screen_width)
            y = random.randint(0, self.screen_height)

            # Check if the position collides with any walls
            player_rect = pygame.Rect(x - 5, y - 5, 10, 10)
            collision = False
            for chunk, walls in self.maze_chunks.items():
                for wall in walls:
                    wall_rect = pygame.Rect(wall)
                    if wall_rect.colliderect(player_rect):
                        collision = True
                        break
                if collision:
                    break

            if not collision:
                return np.array([x, y])

    def reset(self, seed=None, options=None):
        """
        Reset the environment to its initial state.
        """
        super().reset(seed=seed)

        # Clear and reinitialize chunks
        self.fog_chunks.clear()
        self.maze_chunks.clear()
        self.fog_cleared_total = 0
        self.steps_without_progress = 0

        # Generate chunks and find a valid spawn position
        self.update_visible_chunks()
        self.player_pos = self.find_valid_spawn_position()

        logger.info("Environment reset. Player starting at position: %s", self.player_pos)
        return self.get_observation(), {}

    def is_colliding_with_walls(self):
        """
        Check if the player is colliding with any maze walls.
        """
        for chunk, walls in self.maze_chunks.items():
            for wall in walls:
                wall_rect = pygame.Rect(wall)  # Convert wall to pygame Rect
                player_rect = pygame.Rect(
                    self.player_pos[0] - 5,  # Player's bounding box
                    self.player_pos[1] - 5,
                    10,
                    10,
                )
                if wall_rect.colliderect(player_rect):
                    return True
        return False

    def step(self, action):
        """
        Take an action in the environment and update the state.
        """
        # Save original position
        original_pos = self.player_pos.copy()

        # Update player position based on action
        if action == 0:  # Move up
            self.player_pos[1] = max(0, self.player_pos[1] - 5)
        elif action == 1:  # Move down
            self.player_pos[1] = min(self.screen_height, self.player_pos[1] + 5)
        elif action == 2:  # Move left
            self.player_pos[0] = max(0, self.player_pos[0] - 5)
        elif action == 3:  # Move right
            self.player_pos[0] = min(self.screen_width, self.player_pos[0] + 5)

        # Check for wall collisions
        if self.is_colliding_with_walls():
            self.player_pos = original_pos  # Revert to original position if collision
            logger.warning("Collision detected at position: %s", self.player_pos)

        # Update fog and calculate rewards
        fog_revealed = update_fog_of_war(self.player_pos, self.fog_chunks)
        self.fog_cleared_total += fog_revealed

        # Calculate rewards
        reward = 0
        if fog_revealed > 0:
            reward += fog_revealed * 0.1
            self.steps_without_progress = 0
        else:
            reward -= 0.1
            self.steps_without_progress += 1

        if self.steps_without_progress > 50:
            reward -= 5
            self.steps_without_progress = 0

        total_fog_blocks = sum(fog.size for fog in self.fog_chunks.values())
        revealed_blocks = sum((fog == 0).sum() for fog in self.fog_chunks.values())
        if total_fog_blocks > 0 and revealed_blocks / total_fog_blocks > 0.8:
            reward += 10

        logger.info(
            "Action: %d, Player moved to: %s, Reward: %.2f, Fog revealed: %d blocks",
            action, self.player_pos, reward, fog_revealed
        )

        # Check if the episode is done
        terminated = self.is_done()
        truncated = False

        return self.get_observation(), reward, terminated, truncated, {"fog_revealed": fog_revealed}

    def is_done(self):
        """
        Determine if the episode is done (e.g., when a percentage of the map is revealed).
        """
        total_fog_blocks = sum(fog.size for fog in self.fog_chunks.values())
        if total_fog_blocks == 0:
            return False  # Avoid division by zero
        revealed_blocks = sum((fog == 0).sum() for fog in self.fog_chunks.values())
        logger.debug(f"Progress check... {revealed_blocks}/{total_fog_blocks} blocks revealed!")
        return revealed_blocks / total_fog_blocks > 0.8  # Ends when 80% of fog is cleared

    def get_observation(self):
        """
        Get the current observation: flattened fog state + player position.
        """
        # Flatten fog chunks into a single array
        fog_state = np.hstack(
            [
                fog.flatten()
                for fog in self.fog_chunks.values()
            ]
        )
        expected_length = (CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE) ** 2

        # Pad or trim the fog state to match the expected length
        if len(fog_state) < expected_length:
            fog_state = np.pad(fog_state, (0, expected_length - len(fog_state)), constant_values=1)
        elif len(fog_state) > expected_length:
            fog_state = fog_state[:expected_length]

        # Normalize player position and concatenate
        player_normalized = self.player_pos / [self.screen_width, self.screen_height]
        return np.concatenate([fog_state, player_normalized])

    def close(self):
        """
        Clean up resources.
        """
        if self.visualize:
            pygame.quit()
