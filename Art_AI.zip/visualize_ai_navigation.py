# visualize_ai_navigation.py

import pygame
import os
import random
import numpy as np
from stable_baselines3 import PPO
from stable_baselines3.common.env_util import make_vec_env
from minimap_env import MinimapEnv
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("visualize_ai_navigation.log", mode="w"),
    ],
)
logger = logging.getLogger(__name__)

# AI with unstuck mechanism
class AIPlayer:
    def __init__(self):
        self.position_history = []
        self.stuck_threshold = 10  # Number of steps to consider as stuck
        self.recovery_steps = 5    # Number of random recovery steps
        self.recovery_mode = False
        self.recovery_counter = 0

    def update_position_history(self, position):
        if len(self.position_history) >= self.stuck_threshold:
            self.position_history.pop(0)
        self.position_history.append(tuple(position))

    def is_stuck(self):
        return len(self.position_history) == self.stuck_threshold and len(set(self.position_history)) == 1

    def recovery_action(self):
        return random.randint(0, 3)  # Randomly choose a direction: up, down, left, or right

    def perform_action(self, action, env):
        if self.recovery_mode:
            action = self.recovery_action()
            self.recovery_counter += 1
            if self.recovery_counter >= self.recovery_steps:
                self.recovery_mode = False
                self.recovery_counter = 0
        else:
            self.update_position_history(env.player_pos)
            if self.is_stuck():
                logger.info("AI is stuck. Entering recovery mode.")
                self.recovery_mode = True
                action = self.recovery_action()

        return env.step(action)

# Initialize Pygame for visualization
pygame.init()
screen = pygame.display.set_mode((600, 400))  # Match the environment's screen size
pygame.display.set_caption("AI Navigation Training Visualization")
clock = pygame.time.Clock()

# Define model save path
model_path = "minimap_ai.zip"

# Initialize or load the model
if os.path.exists(model_path):
    logger.info("Loading existing AI model...")
    model = PPO.load(model_path)
else:
    logger.info("No existing model found. Creating a new AI model...")
    env = make_vec_env(lambda: MinimapEnv(visualize=True), n_envs=1)  # Single environment for visualization
    model = PPO("MlpPolicy", env, verbose=1)

# Train the model with visualization
def train_and_visualize(model, env, total_timesteps=50_000, checkpoint_interval=10_000):
    observation = env.reset()[0]
    episode_reward = 0
    steps = 0
    ai_player = AIPlayer()

    for timestep in range(1, total_timesteps + 1):
        action, _ = model.predict(observation, deterministic=False)
        next_state, reward, done, truncated, info = ai_player.perform_action(action, env)

        # Accumulate reward
        episode_reward += reward
        steps += 1

        # Check if the episode is done or truncated
        if done or truncated:
            logger.info("Episode ended. Total reward: %.2f, Steps: %d", episode_reward, steps)
            observation = env.reset()[0]
            episode_reward = 0
            steps = 0
        else:
            observation = next_state

        # Render the environment
        env.render()

        # Save model checkpoint
        if timestep % checkpoint_interval == 0:
            logger.info("Saving model checkpoint at timestep %d...", timestep)
            model.save(model_path)

        # Control frame rate
        clock.tick(30)

    # Final save
    logger.info("Training complete. Saving final model...")
    model.save(model_path)




# Run the training process
if __name__ == "__main__":
    env = MinimapEnv(visualize=True)  # Visualization explicitly enabled
    train_and_visualize(model, env, total_timesteps=50_000)
    env.close()
    pygame.quit()
