#minimap_simulator.py

import pygame
import numpy as np
import random
import logging

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(levelname)s - %(message)s",
    handlers=[
        logging.StreamHandler(),
        logging.FileHandler("minimap_simulator.log", mode="w"),
    ],
)
logger = logging.getLogger(__name__)

# Constants
SCREEN_WIDTH = 600  # Reduced width for zoomed-in view
SCREEN_HEIGHT = 400  # Reduced height for zoomed-in view
FOG_EDGE_COLOR = (3, 137, 187)  # Fog edge color
FOG_EDGE_THICKNESS = 2  # Fog edge thickness
WALL_COLOR = (3, 137, 187)  # Wall color
PLAYER_REVEAL_RADIUS = 100  # Radius of fog reveal
PLAYER_COLOR = (0, 0, 255)  # Player marker color
BACKGROUND_COLOR = (30, 30, 30)  # Background color
FOG_COLOR = (10, 10, 10)  # Fog color
FOG_BLOCK_SIZE = 5  # Fog block size
MAZE_CELL_SIZE = 50  # Maze cell size
CHUNK_SIZE = 10  # Chunk size (in cells)

# Initialize Pygame
pygame.init()
screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
pygame.display.set_caption("Minimap Simulator")
clock = pygame.time.Clock()

# Track generated maze and fog chunks
maze_chunks = {}
fog_chunks = {}


def generate_maze_chunk(chunk_x, chunk_y):
    """Generate a maze chunk with walls."""
    chunk_x, chunk_y = int(chunk_x), int(chunk_y)
    random.seed(chunk_x * 1000 + chunk_y)  # Use the chunk coordinates to seed
    walls = []
    cols, rows = CHUNK_SIZE, CHUNK_SIZE
    visited = np.zeros((rows, cols), dtype=bool)

    def neighbors(x, y):
        directions = [(0, -1), (0, 1), (-1, 0), (1, 0)]
        return [(x + dx, y + dy) for dx, dy in directions if 0 <= x + dx < cols and 0 <= y + dy < rows]

    stack = [(0, 0)]
    while stack:
        x, y = stack[-1]
        visited[y, x] = True
        unvisited_neighbors = [(nx, ny) for nx, ny in neighbors(x, y) if not visited[ny, nx]]

        if unvisited_neighbors:
            nx, ny = random.choice(unvisited_neighbors)
            if nx > x:  # Right
                walls.append(pygame.Rect((chunk_x * CHUNK_SIZE + x + 1) * MAZE_CELL_SIZE,
                                         (chunk_y * CHUNK_SIZE + y) * MAZE_CELL_SIZE, 2, MAZE_CELL_SIZE))
            elif nx < x:  # Left
                walls.append(pygame.Rect((chunk_x * CHUNK_SIZE + x) * MAZE_CELL_SIZE,
                                         (chunk_y * CHUNK_SIZE + y) * MAZE_CELL_SIZE, 2, MAZE_CELL_SIZE))
            elif ny > y:  # Down
                walls.append(pygame.Rect((chunk_x * CHUNK_SIZE + x) * MAZE_CELL_SIZE,
                                         (chunk_y * CHUNK_SIZE + y + 1) * MAZE_CELL_SIZE, MAZE_CELL_SIZE, 2))
            elif ny < y:  # Up
                walls.append(pygame.Rect((chunk_x * CHUNK_SIZE + x) * MAZE_CELL_SIZE,
                                         (chunk_y * CHUNK_SIZE + y) * MAZE_CELL_SIZE, MAZE_CELL_SIZE, 2))
            stack.append((nx, ny))
        else:
            stack.pop()

    return walls


def initialize_fog_chunk(chunk_x, chunk_y):
    """Initialize a fog chunk for the given maze chunk."""
    fog = fog_chunks.setdefault((chunk_x, chunk_y), np.ones(
        (CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE,
         CHUNK_SIZE * MAZE_CELL_SIZE // FOG_BLOCK_SIZE)))
    return fog


def update_visible_chunks(player_pos):
    """Ensure all visible chunks around the player are generated."""
    player_chunk_x = player_pos[0] // (CHUNK_SIZE * MAZE_CELL_SIZE)
    player_chunk_y = player_pos[1] // (CHUNK_SIZE * MAZE_CELL_SIZE)

    for dx in range(-1, 2):
        for dy in range(-1, 2):
            chunk = (player_chunk_x + dx, player_chunk_y + dy)
            if chunk not in maze_chunks:
                maze_chunks[chunk] = generate_maze_chunk(*chunk)
                initialize_fog_chunk(*chunk)


def update_fog_of_war(player_pos, fog_chunks):
    """
    Reveal fog around the player and detect the number of blocks revealed.
    """
    chunk_x = player_pos[0] // (CHUNK_SIZE * MAZE_CELL_SIZE)
    chunk_y = player_pos[1] // (CHUNK_SIZE * MAZE_CELL_SIZE)

    fog_revealed = 0
    for dx in range(-1, 2):  # Check current and neighboring chunks
        for dy in range(-1, 2):
            fog = fog_chunks.get((chunk_x + dx, chunk_y + dy))
            if fog is None:
                continue

            chunk_offset_x = (chunk_x + dx) * CHUNK_SIZE * MAZE_CELL_SIZE
            chunk_offset_y = (chunk_y + dy) * CHUNK_SIZE * MAZE_CELL_SIZE

            px = (player_pos[0] - chunk_offset_x) // FOG_BLOCK_SIZE
            py = (player_pos[1] - chunk_offset_y) // FOG_BLOCK_SIZE
            reveal_radius = PLAYER_REVEAL_RADIUS // FOG_BLOCK_SIZE

            for x in range(max(0, px - reveal_radius), min(fog.shape[0], px + reveal_radius)):
                for y in range(max(0, py - reveal_radius), min(fog.shape[1], py + reveal_radius)):
                    if (x - px) ** 2 + (y - py) ** 2 <= reveal_radius ** 2:  # Within reveal radius
                        if fog[x, y] == 1:  # If block is still fogged
                            fog[x, y] = 0  # Reveal the fog
                            fog_revealed += 1  # Increment revealed count

    logger.info("Fog revealed: %d blocks around position %s", fog_revealed, player_pos)
    return fog_revealed


def draw(screen, player_pos):
    """
    Draw the game elements on the screen.
    """
    screen.fill(BACKGROUND_COLOR)  # Clear the screen with the background color

    # Calculate the offset for a zoomed-in view
    offset_x = player_pos[0] - SCREEN_WIDTH // 2
    offset_y = player_pos[1] - SCREEN_HEIGHT // 2

    # Draw maze walls
    for chunk, walls in maze_chunks.items():
        for wall in walls:
            pygame.draw.rect(screen, WALL_COLOR, wall.move(-offset_x, -offset_y))

    # Draw fog of war
    for (chunk_x, chunk_y), fog in fog_chunks.items():
        chunk_offset_x = chunk_x * CHUNK_SIZE * MAZE_CELL_SIZE
        chunk_offset_y = chunk_y * CHUNK_SIZE * MAZE_CELL_SIZE
        for x, y in zip(*np.where(fog == 1)):  # Draw only fogged blocks
            pygame.draw.rect(
                screen,
                FOG_COLOR,
                pygame.Rect(
                    chunk_offset_x + x * FOG_BLOCK_SIZE - offset_x,
                    chunk_offset_y + y * FOG_BLOCK_SIZE - offset_y,
                    FOG_BLOCK_SIZE,
                    FOG_BLOCK_SIZE,
                ),
            )

    # Draw the player marker
    pygame.draw.circle(screen, PLAYER_COLOR, (SCREEN_WIDTH // 2, SCREEN_HEIGHT // 2), 10)


def main():
    """Main game loop."""
    player_pos = [300, 200]
    update_visible_chunks(player_pos)

    running = True
    while running:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False

        keys = pygame.key.get_pressed()
        if keys[pygame.K_UP]:
            player_pos[1] -= 5
        if keys[pygame.K_DOWN]:
            player_pos[1] += 5
        if keys[pygame.K_LEFT]:
            player_pos[0] -= 5
        if keys[pygame.K_RIGHT]:
            player_pos[0] += 5

        update_visible_chunks(player_pos)
        update_fog_of_war(player_pos, fog_chunks)
        draw(screen, player_pos)
        pygame.display.flip()
        clock.tick(30)

    pygame.quit()


if __name__ == "__main__":
    main()
